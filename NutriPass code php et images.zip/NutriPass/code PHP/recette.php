<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Configuration de la connexion
$host    = 'bdd-test.f-dufour.com';$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';$pass    = '5Ve*r93HiyM$5C@ILi9O';$charset = 'utf8mb4';

$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
$repasList = [];$errorMsg = null;
$isConnected = false;

try {
    $pdo = new PDO($dsn,$user, $pass, [         PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,         PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,     ]);$isConnected = true; 
    
    // On ne sélectionne PAS le BLOB ici pour éviter la surcharge / "has gone away"
    $stmt =$pdo->query("SELECT id, nom_repas FROM repas ORDER BY id ASC");
    $repasList =$stmt->fetchAll();
    
} catch (PDOException $e) {$errorMsg = "Impossible de récupérer les repas : " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="fr">    
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes repas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #9d1818;
            color: white;
            margin: 0;
            padding: 30px;
        }
        h1 { 
            text-align: center; 
            color: white;
        }
        .alert { 
            text-align: center; 
            padding: 12px; 
            border-radius: 8px; 
            margin-bottom: 20px; 
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .error { 
            color: #ffcccc; 
            background: rgba(0,0,0,0.4); 
            border: 1px solid rgba(255, 0, 0, 0.3);
        }
        .success { 
            color: #d4edda; 
            background: rgba(40, 167, 69, 0.3); 
            border: 1px solid rgba(40, 167, 69, 0.5);
        }
        .repas {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            max-width: 1000px;
            margin: 30px auto;
        }
        .repas img {
            width: 100%;
            border-radius: 12px;
            display: block;
        }
    </style>
</head>
<body>

    <h1>Mes repas</h1>

    <?php if ($isConnected && !$errorMsg): ?>
        <div class="alert success">🟢 Connecté à la base de données (`<?= htmlspecialchars($db) ?>`) avec succès !</div>
    <?php endif; ?>

    <?php if ($errorMsg): ?>
        <div class="alert error">🔴 <?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>

    <div class="repas">
        <?php if (!empty($repasList)): ?>
            <?php foreach ($repasList as$item): ?>
                <?php 
                    $id  = htmlspecialchars($item['id'] ?? '');$alt = htmlspecialchars($item['nom_repas'] ?? "Repas $id");
                ?>
                <img src="image.php?id=<?= $item['id'] ?>" alt="<?= $alt ?>">
            <?php endforeach; ?>
        <?php else: ?>
            <?php for ($i = 1; $i <= 15; $i++): ?>
                <img src="images/repas/<?= $i ?>.png" alt="Repas <?= $i ?>">
            <?php endfor; ?>
        <?php endif; ?>
    </div>

</body>
</html>