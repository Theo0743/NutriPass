<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host    = 'bdd-test.f-dufour.com';
$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';
$pass    = '5Ve*r93HiyM$5C@ILi9O';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
$stocks = [];
$aliments = [];
$errorMsg = null;
$successMsg = null;
$isConnected = false;

$nbAstronautes = 18; // Milieu de la fourchette 15-20
$consommationJourEstimee_g = $nbAstronautes * 2000; 

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 10,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
    ]);
    $isConnected = true;
    
    // 1. Traitement de l'ajout de stock en POST
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajouter_stock'])) {
        $alimentId      = intval($_POST['aliment_id'] ?? 0);
        $quantiteG      = floatval($_POST['quantite_g'] ?? 0);
        $datePeremption = trim($_POST['date_peremption'] ?? '');
        $dateEntree     = date('Y-m-d H:i:s');

        if ($alimentId > 0 && $quantiteG > 0 && !empty($datePeremption)) {
            $sqlInsert = "INSERT INTO stock (aliment_id, quantite_g, date_entree, date_peremption) VALUES (?, ?, ?, ?)";
            $stmtInsert = $pdo->prepare($sqlInsert);
            $stmtInsert->execute([$alimentId, $quantiteG, $dateEntree, $datePeremption]);
            
            $successMsg = "Nouveau stock ajouté avec succès !";
        } else {
            $errorMsg = "Veuillez remplir correctement tous les champs du formulaire d'ajout.";
        }
    }

    // 2. Récupération de la liste des aliments pour le menu déroulant
    $stmtAliments = $pdo->query("SELECT id, nom FROM aliment ORDER BY nom ASC");
    $aliments = $stmtAliments->fetchAll();
    
    // 3. Récupération des stocks existants (masque les stocks à 0 ou négatifs tout en les gardant en BDD)
    $sql = "SELECT s.id, s.aliment_id, a.nom AS nom_aliment, s.quantite_g, s.date_peremption, s.date_entree
            FROM stock s
            LEFT JOIN aliment a ON s.aliment_id = a.id
            WHERE s.quantite_g > 0
            ORDER BY s.date_peremption ASC
            LIMIT 100";
            
    $stmt = $pdo->query($sql);
    if ($stmt) {
        $stocks = $stmt->fetchAll();
    } else {
        $errorMsg = "Échec de l'exécution de la requête SQL de sélection.";
    }
    
} catch (PDOException $e) {
    $errorMsg = "Erreur de connexion/requête distante : " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Stock & Survie Spatiale (<?= $nbAstronautes ?> pax)</title>
    <style>
        body { font-family: Arial, sans-serif; background: #1a1a2e; color: white; padding: 30px; margin: 0; }
        h1, h2 { text-align: center; color: #e2e8f0; }
        .info-panel { background: rgba(255,255,255,0.08); padding: 15px; border-radius: 8px; max-width: 1000px; margin: 0 auto 20px auto; display: flex; justify-content: space-around; font-size: 1.1rem; }
        .status-bar { text-align: center; margin-bottom: 20px; font-weight: bold; }
        .error { color: #ffcccc; background: rgba(255,0,0,0.3); padding: 15px; border-radius: 8px; max-width: 1000px; margin: 0 auto 20px auto; text-align: center; }
        .success { color: #ccffcc; background: rgba(0,255,0,0.2); padding: 15px; border-radius: 8px; max-width: 1000px; margin: 0 auto 20px auto; text-align: center; }
        
        .form-container { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); padding: 20px; border-radius: 8px; max-width: 1000px; margin: 0 auto 30px auto; box-sizing: border-box; }
        .form-grid { display: grid; grid-template-columns: repeat(3, 1fr) auto; gap: 15px; align-items: end; }
        .form-group label { display: block; margin-bottom: 5px; font-size: 0.9rem; color: #38bdf8; }
        .form-group select, .form-group input { width: 100%; padding: 10px; border-radius: 6px; border: none; background: rgba(0,0,0,0.4); color: white; box-sizing: border-box; }
        .btn-ajouter { background: #4ade80; color: #1a1a2e; border: none; padding: 10px 20px; font-weight: bold; border-radius: 6px; cursor: pointer; height: 38px; }
        .btn-ajouter:hover { background: #22c55e; }

        table { width: 100%; border-collapse: collapse; background: rgba(0,0,0,0.35); border-radius: 8px; overflow: hidden; max-width: 1000px; margin: 0 auto; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.1); }
        th { background: rgba(0,0,0,0.6); }
        .critique { background: rgba(255, 0, 0, 0.35); color: #ffcccc; font-weight: bold; }
        .alerte { background: rgba(255, 165, 0, 0.3); color: #ffe6cc; }
    </style>
</head>
<body>
    <h1>🛰️ Suivi des Stocks - Station Spatiale</h1>
    
    <div class="status-bar">
        <?php if ($isConnected && !$errorMsg): ?>
            <span style="color: #4ade80;">🟢 Connecté à la base distante (port <?= $port ?>)</span>
        <?php else: ?>
            <span style="color: #f87171;">🔴 Déconnecté ou erreur serveur distant</span>
        <?php endif; ?>
    </div>

    <div class="info-panel">
        <div>👨‍🚀 <strong>Équipage actif :</strong> <?= $nbAstronautes ?> pax (fourchette 15-20)</div>
        <div>⚖️ <strong>Conso globale estimée :</strong> ~<?= number_format($consommationJourEstimee_g/1000, 1) ?> kg/j</div>
    </div>

    <?php if ($errorMsg): ?>
        <div class="error"><?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>

    <?php if ($successMsg): ?>
        <div class="success"><?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>

    <!-- Formulaire d'ajout de stock -->
    <div class="form-container">
        <h2>➕ Ajouter un aliment au stock</h2>
        <form method="POST" class="form-grid">
            <div class="form-group">
                <label for="aliment_id">Aliment :</label>
                <select name="aliment_id" id="aliment_id" required>
                    <option value="">-- Sélectionner un aliment --</option>
                    <?php foreach ($aliments as $aliment): ?>
                        <option value="<?= $aliment['id'] ?>"><?= htmlspecialchars($aliment['nom']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="quantite_g">Quantité (en grammes) :</label>
                <input type="number" step="any" name="quantite_g" id="quantite_g" placeholder="Ex: 5000" required>
            </div>
            <div class="form-group">
                <label for="date_peremption">Date de péremption :</label>
                <input type="date" name="date_peremption" id="date_peremption" required>
            </div>
            <div>
                <button type="submit" name="ajouter_stock" class="btn-ajouter">Ajouter</button>
            </div>
        </form>
    </div>

    <!-- Tableau d'affichage des stocks actifs -->
    <table>
        <thead>
            <tr>
                <th>Nom de l'aliment</th>
                <th>Quantité (g)</th>
                <th>Autonomie unitaire (~200g/j)</th>
                <th>Date d'entrée</th>
                <th>Date de péremption</th>
                <th>Statut</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($stocks)): ?>
                <?php foreach ($stocks as $s): ?>
                    <?php 
                        $alimNom = $s['nom_aliment'] ?? 'Aliment inconnu #' . $s['aliment_id'];
                        $joursRestants = (strtotime($s['date_peremption']) - time()) / 86400;
                        $classRow = '';
                        $statutPéremption = 'OK';
                        
                        if ($joursRestants < 3) {
                            $classRow = 'critique';
                            $statutPéremption = '🔴 CRITIQUE (<3j)';
                        } elseif ($joursRestants < 7) {
                            $classRow = 'alerte';
                            $statutPéremption = '🟠 Proche (<7j)';
                        }
                        
                        $autonomieJours = round($s['quantite_g'] / 200, 1);
                    ?>
                    <tr class="<?= $classRow ?>">
                        <td><strong><?= htmlspecialchars($alimNom) ?></strong></td>
                        <td><?= number_format($s['quantite_g'], 1, ',', ' ') ?> g</td>
                        <td>~<?= $autonomieJours ?> j-pers.</td>
                        <td><?= htmlspecialchars($s['date_entree']) ?></td>
                        <td><?= htmlspecialchars($s['date_peremption']) ?></td>
                        <td><?= $statutPéremption ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align: center;">Aucun stock actif trouvé.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>