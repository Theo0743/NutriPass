<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Redirection vers le login si non connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$currentNiveauActivite = $_SESSION['niveau_activite_id'] ?? null;
$isAdmin = ($currentNiveauActivite == 16);

// Configuration de la connexion
$host    = 'bdd-test.f-dufour.com';
$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';
$pass    = '5Ve*r93HiyM$5C@ILi9O';
$charset = 'utf8mb4';
$dsn     = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";

$pdo = null;
$errorMsg = null;
$successMsg = null;
$isConnected = false;

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $isConnected = true;
} catch (PDOException $e) {
    $errorMsg = "Erreur de connexion : " . $e->getMessage();
}

// Traitement des formulaires en POST si admin
if ($isAdmin && $isConnected && $_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Cas 1 : Modification du mot de passe d'un astronaute existant depuis le tableau
    if (isset($_POST['modifier_mdp'])) {
        $astroIdToUpdate = intval($_POST['astronaute_id'] ?? 0);
        $nouveauMdpClair = trim($_POST['nouveau_mdp'] ?? '');

        // Utilisation de strlen() au lieu de mb_strlen()
        if ($astroIdToUpdate > 0 && strlen($nouveauMdpClair) === 4) {
            try {
                $mdpCrypte = password_hash($nouveauMdpClair, PASSWORD_DEFAULT);
                $stmtUpd = $pdo->prepare("UPDATE astronaute SET mdp = ? WHERE id = ?");
                $stmtUpd->execute([$mdpCrypte, $astroIdToUpdate]);
                $successMsg = "Le mot de passe de l'astronaute #$astroIdToUpdate a été mis à jour avec succès !";
            } catch (PDOException $e) {
                $errorMsg = "Erreur lors de la mise à jour du mot de passe : " . $e->getMessage();
            }
        } else {
            $errorMsg = "Erreur : Le nouveau mot de passe doit comporter exactement 4 caractères.";
        }
    } 
    // Cas 2 : Ajout d'un nouvel astronaute
    elseif (isset($_POST['ajouter_astronaute'])) {
        $nom                = trim($_POST['nom'] ?? '');
        $prenom             = trim($_POST['prenom'] ?? '');
        $taille_cm          = trim($_POST['taille_cm'] ?? '');
        $poids_kg           = trim($_POST['poids_kg'] ?? '');
        $date_naissance     = trim($_POST['date_naissance'] ?? '');
        $sexe               = trim($_POST['sexe'] ?? '');
        $niveau_activite_id = trim($_POST['niveau_activite_id'] ?? '16');
        $mdpClair           = trim($_POST['mdp'] ?? '');

        if ($nom && $prenom) {
            // Utilisation de strlen() au lieu de mb_strlen()
            if ($mdpClair !== '' && strlen($mdpClair) !== 4) {
                $errorMsg = "Erreur : Le mot de passe doit comporter exactement 4 caractères.";
            } else {
                try {
                    $mdpCrypte = ($mdpClair !== '') ? password_hash($mdpClair, PASSWORD_DEFAULT) : null;

                    $stmt = $pdo->prepare("INSERT INTO astronaute (nom, prenom, taille_cm, poids_kg, date_naissance, sexe, niveau_activite_id, mdp) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $nom, 
                        $prenom, 
                        $taille_cm !== '' ? $taille_cm : null, 
                        $poids_kg !== '' ? $poids_kg : null, 
                        $date_naissance !== '' ? $date_naissance : null, 
                        $sexe !== '' ? $sexe : null, 
                        $niveau_activite_id !== '' ? $niveau_activite_id : 16,
                        $mdpCrypte
                    ]);
                    $successMsg = "Nouvel astronaute ajouté avec succès !";
                } catch (PDOException $e) {
                    $errorMsg = "Erreur lors de l'insertion : " . $e->getMessage();
                }
            }
        } else {
            $errorMsg = "Le nom et le prénom sont obligatoires.";
        }
    }
}

// Récupération de la liste des astronautes
$astronauteList = [];
if ($isAdmin && $isConnected) {
    try {
        $stmt = $pdo->query("SELECT id, nom, prenom, taille_cm, poids_kg, date_naissance, sexe, niveau_activite_id, mdp FROM astronaute ORDER BY id ASC");
        $astronauteList = $stmt->fetchAll();
    } catch (PDOException $e) {
        $errorMsg = "Impossible de récupérer la liste des astronautes : " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Astronautes</title>
    <style>
        body { font-family: Arial, sans-serif; background: #9d1818; color: white; margin: 0; padding: 30px; }
        .top-bar { display: flex; justify-content: space-between; align-items: center; max-width: 1100px; margin: 0 auto 20px auto; }
        .logout-btn { background: rgba(0,0,0,0.4); color: white; text-decoration: none; padding: 8px 16px; border-radius: 6px; font-size: 0.9rem; border: 1px solid rgba(255,255,255,0.2); }
        .logout-btn:hover { background: rgba(0,0,0,0.6); }
        h1, h2 { text-align: center; color: white; }
        .alert { text-align: center; padding: 12px; border-radius: 8px; margin-bottom: 20px; max-width: 600px; margin-left: auto; margin-right: auto; }
        .error { color: #ffcccc; background: rgba(0,0,0,0.4); border: 1px solid rgba(255, 0, 0, 0.3); }
        .success { color: #d4edda; background: rgba(40, 167, 69, 0.3); border: 1px solid rgba(40, 167, 69, 0.5); }
        .container { max-width: 1100px; margin: 0 auto; background: rgba(0,0,0,0.25); padding: 25px; border-radius: 12px; margin-bottom: 30px; }
        form.add-form { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, select { width: 100%; padding: 10px; border-radius: 6px; border: none; box-sizing: border-box; background: rgba(255,255,255,0.9); color: #000; }
        button.btn-main { background: #40a745; color: white; border: none; padding: 12px; font-weight: bold; border-radius: 6px; cursor: pointer; grid-column: span 2; }
        button.btn-main:hover { background: #338a37; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; background: rgba(0,0,0,0.3); border-radius: 8px; overflow: hidden; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid rgba(255,255,255,0.1); font-size: 0.9rem; vertical-align: middle; }
        th { background: rgba(0,0,0,0.4); }
        .inline-form { display: flex; gap: 5px; align-items: center; }
        .inline-form input { width: 75px; padding: 6px; text-align: center; font-size: 0.85rem; }
        .btn-sm { background: #007bff; color: white; border: none; padding: 6px 10px; font-size: 0.8rem; border-radius: 4px; cursor: pointer; white-space: nowrap; }
        .btn-sm:hover { background: #0056b3; }
    </style>
</head>
<body>

    <div class="top-bar">
        <span>Connecté(e) - ID utilisateur : <strong><?= htmlspecialchars($_SESSION['user_id']) ?></strong> (Niveau activité : <strong><?= htmlspecialchars($currentNiveauActivite ?? '-') ?></strong>)</span>
        <a href="logout.php" class="logout-btn">Déconnexion</a>
    </div>

    <h1>Dashboard Admin — Gestion des Astronautes</h1>

    <?php if ($errorMsg): ?>
        <div class="alert error">🔴 <?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>
    <?php if ($successMsg): ?>
        <div class="alert success">🟢 <?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>

    <?php if (!$isAdmin): ?>
        <div class="alert error">⛔ Accès refusé : Réservé strictement aux profils ayant un niveau d'activité ID 16 (votre niveau actuel : <?= htmlspecialchars($currentNiveauActivite ?? 'aucun') ?>).</div>
    <?php else: ?>
        <!-- Formulaire de création -->
        <div class="container">
            <h2>Ajouter un astronaute</h2>
            <form method="POST" class="add-form">
                <div>
                    <label for="nom">Nom :</label>
                    <input type="text" id="nom" name="nom" required>
                </div>
                <div>
                    <label for="prenom">Prénom :</label>
                    <input type="text" id="prenom" name="prenom" required>
                </div>
                <div>
                    <label for="taille_cm">Taille (cm) :</label>
                    <input type="number" id="taille_cm" name="taille_cm">
                </div>
                <div>
                    <label for="poids_kg">Poids (kg) :</label>
                    <input type="number" step="0.1" id="poids_kg" name="poids_kg">
                </div>
                <div>
                    <label for="date_naissance">Date de naissance :</label>
                    <input type="date" id="date_naissance" name="date_naissance">
                </div>
                <div>
                    <label for="sexe">Sexe :</label>
                    <input type="text" id="sexe" name="sexe" maxlength="1" placeholder="M/F">
                </div>
                <div>
                    <label for="niveau_activite_id">Niveau d'activité (ID) :</label>
                    <input type="number" id="niveau_activite_id" name="niveau_activite_id" value="16">
                </div>
                <div>
                    <label for="mdp">Mot de passe (4 caractères) :</label>
                    <input type="password" id="mdp" name="mdp" maxlength="4" minlength="4" placeholder="Ex: 1234" required>
                </div>
                <button type="submit" name="ajouter_astronaute" class="btn-main">Enregistrer l'astronaute</button>
            </form>
        </div>

        <!-- Consultation et modification depuis la liste -->
        <div class="container">
            <h2>Liste des astronautes & Gestion des MDP</h2>
            <?php if (!empty($astronauteList)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nom</th>
                            <th>Prénom</th>
                            <th>Taille</th>
                            <th>Poids</th>
                            <th>Naiss.</th>
                            <th>Sexe</th>
                            <th>Activité ID</th>
                            <th>Modifier MDP (4 car.)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($astronauteList as $astro): ?>
                            <tr>
                                <td><?= htmlspecialchars($astro['id']) ?></td>
                                <td><?= htmlspecialchars($astro['nom']) ?></td>
                                <td><?= htmlspecialchars($astro['prenom']) ?></td>
                                <td><?= htmlspecialchars($astro['taille_cm'] ?? '-') ?> cm</td>
                                <td><?= htmlspecialchars($astro['poids_kg'] ?? '-') ?> kg</td>
                                <td><?= htmlspecialchars($astro['date_naissance'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($astro['sexe'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($astro['niveau_activite_id'] ?? '-') ?></td>
                                <td>
                                    <form method="POST" class="inline-form">
                                        <input type="hidden" name="astronaute_id" value="<?= $astro['id'] ?>">
                                        <input type="password" name="nouveau_mdp" maxlength="4" minlength="4" placeholder="****" required>
                                        <button type="submit" name="modifier_mdp" class="btn-sm">Modifier</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="text-align: center;">Aucun astronaute enregistré pour le moment.</p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

</body>
</html>