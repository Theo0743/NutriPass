<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host    = 'bdd-test.f-dufour.com';$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';$pass    = '5Ve*r93HiyM$5C@ILi9O';
$charset = 'utf8mb4';$dsn     = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";

try {
    $pdo = new PDO($dsn, $user,$pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
    ]);

    // 1. Vérifions combien d'astronautes existent dans la table
    $stmtCount =$pdo->query("SELECT COUNT(*) FROM astronaute");
    $totalAstronautes =$stmtCount->fetchColumn();

    if ($totalAstronautes == 0) {
        echo "⚠️ La table `astronaute` est totalement vide ! Il faut d'abord créer des astronautes depuis ton Dashboard Admin.";
        exit;
    }

    // 2. Génération du hachage pour le mot de passe "1234" (4 caractères)
    $motDePasseDefaut = "1234";
    $mdpCrypte = password_hash($motDePasseDefaut, PASSWORD_DEFAULT);

    // 3. Mise à jour de tous les astronautes qui n'ont pas de mot de passe (ou pour forcer sur tout le monde, retire le WHERE)
    $stmt =$pdo->prepare("UPDATE astronaute SET mdp = ? WHERE mdp IS NULL OR mdp = ''");
    $stmt->execute([$mdpCrypte]);
    
    $lignesModifiees =$stmt->rowCount();

    echo "<h3>✅ Opération réussie !</h3>";
    echo "<ul>";
    echo "<li>Nombre total d'astronautes dans la table : <strong>$totalAstronautes</strong></li>";
    echo "<li>Nombre de mots de passe mis à jour : <strong>$lignesModifiees</strong></li>";
    echo "<li>Mot de passe par défaut attribué : <strong>1234</strong> (crypté en BDD)</li>";
    echo "</ul>";
    echo "<p>Tu peux maintenant tester la connexion avec le mot de passe <b>1234</b>.</p>";

} catch (PDOException $e) {
    echo "❌ Erreur de connexion ou SQL : " . $e->getMessage();
}
?>