<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host    = 'bdd-test.f-dufour.com';
$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';
$pass    = '5Ve*r93HiyM$5C@ILi9O';
$charset = 'utf8mb4';
$dsn     = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";

$errorMsg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nomInput      = trim($_POST['nom'] ?? '');
    $prenomInput   = trim($_POST['prenom'] ?? '');
    $passwordInput = trim($_POST['mdp'] ?? '');

    if ($nomInput !== '' && $prenomInput !== '' && $passwordInput !== '') {
        try {
            $pdo = new PDO($dsn, $user, $pass, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);

            // Recherche de l'astronaute par nom et prénom
            $stmt = $pdo->prepare("SELECT id, nom, prenom, niveau_activite_id, mdp FROM astronaute WHERE LOWER(TRIM(nom)) = LOWER(TRIM(?)) AND LOWER(TRIM(prenom)) = LOWER(TRIM(?))");
            $stmt->execute([$nomInput, $prenomInput]);
            $userFound = $stmt->fetch();

            if ($userFound) {
                $niveau = (int)$userFound['niveau_activite_id'];
                $mdpBdd = $userFound['mdp'];

                // Vérification du mot de passe crypté
                if (!empty($mdpBdd) && password_verify($passwordInput, $mdpBdd)) {

                    // Vérification des accès autorisés (ID 16, 7 ou 5)
                    if (in_array($niveau, [16, 7, 5])) {
                        $_SESSION['user_id'] = $userFound['id'];
                        $_SESSION['niveau_activite_id'] = $niveau;
                        $_SESSION['user_nom'] = $userFound['prenom'] . ' ' . $userFound['nom'];

                        // Redirection dynamique selon le rôle
                        if ($niveau === 16) {
                            header('Location: dashboard.php');
                            exit;
                        } elseif ($niveau === 7) {
                            header('Location: reclamation.php');
                            exit;
                        } elseif ($niveau === 5) {
                            header('Location: stock.php');
                            exit;
                        }
                    } else {
                        $errorMsg = "Accès refusé : Votre profil (Niveau d'activité ID " . $niveau . ") n'a pas les droits requis.";
                    }
                } else {
                    $errorMsg = "Mot de passe incorrect ou non configuré pour cet utilisateur.";
                }
            } else {
                $errorMsg = "Aucun astronaute trouvé avec ce nom et ce prénom.";
            }
        } catch (PDOException $e) {
            $errorMsg = "Erreur de connexion à la BDD : " . $e->getMessage();
        }
    } else {
        $errorMsg = "Veuillez renseigner le nom, le prénom et le mot de passe (4 caractères).";
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - Station Spatiale</title>
    <style>
        body { font-family: Arial, sans-serif; background: #9d1818; color: white; margin: 0; padding: 30px; display: flex; justify-content: center; align-items: center; height: 80vh; }
        .login-box { background: rgba(0,0,0,0.3); padding: 30px; border-radius: 12px; width: 100%; max-width: 400px; box-sizing: border-box; }
        h1 { text-align: center; font-size: 1.5rem; margin-top: 0; }
        .alert { text-align: center; padding: 10px; border-radius: 8px; margin-bottom: 15px; font-size: 0.9rem; }
        .error { color: #ffcccc; background: rgba(0,0,0,0.4); border: 1px solid rgba(255, 0, 0, 0.3); }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input { width: 100%; padding: 10px; border-radius: 6px; border: none; box-sizing: border-box; margin-bottom: 15px; background: rgba(255,255,255,0.9); color: #000; }
        button { width: 100%; background: #40a745; color: white; border: none; padding: 12px; font-weight: bold; border-radius: 6px; cursor: pointer; }
        button:hover { background: #338a37; }
        .btn-link { background: #007bff; margin-top: 10px; }
        .btn-link:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="login-box">
        <h1>Connexion Station</h1>
        <?php if ($errorMsg): ?>
            <div class="alert error">🔴 <?= htmlspecialchars($errorMsg) ?></div>
        <?php endif; ?>
        <form method="POST">
            <label for="nom">Nom :</label>
            <input type="text" id="nom" name="nom" required>

            <label for="prenom">Prénom :</label>
            <input type="text" id="prenom" name="prenom" required>

            <label for="mdp">Mot de passe (4 caractères) :</label>
            <input type="password" id="mdp" name="mdp" maxlength="4" minlength="4" required>

            <button type="submit">Se connecter</button>
        </form>
    </div>
</body>
</html>