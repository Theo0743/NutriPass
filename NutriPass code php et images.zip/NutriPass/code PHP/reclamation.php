<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host    = 'bdd-test.f-dufour.com';
$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';
$pass    = '5Ve*r93HiyM$5C@ILi9O';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";
$commandesGroupées = [];
$errorMsg = null;
$successMsg = null;

try {
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_TIMEOUT => 10,
    ]);
    
    // Traitement de la validation groupée
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['valider_ids'])) {
        $idsAValider = $_POST['valider_ids'];
        $idsAValider = array_map('intval', $idsAValider);
        
        if (!empty($idsAValider)) {
            $placeholders = implode(',', array_fill(0, count($idsAValider), '?'));
            $sqlUpdate = "UPDATE reclamation SET statut = 'valide' WHERE id IN ($placeholders)";
            $stmtUpd = $pdo->prepare($sqlUpdate);
            $stmtUpd->execute($idsAValider);
            
            $successMsg = "La commande groupée a été validée et masquée du visuel.";
        }
    }
    
    // Récupération des réclamations en attente
    $sql = "SELECT 
                rec.id,
                rec.repas_id,
                rec.meal_type,
                rec.portion_size,
                rec.date_reclamation,
                rec.astronaute_id,
                rep.nom_repas,
                rep.image_repas,
                ast.prenom AS prenom_astronaute,
                ast.nom AS nom_astronaute
            FROM reclamation rec
            LEFT JOIN repas rep ON rec.repas_id = rep.id
            LEFT JOIN astronaute ast ON rec.astronaute_id = ast.id
            WHERE rec.statut IS NULL OR rec.statut != 'valide'
            ORDER BY rec.date_reclamation DESC, rec.astronaute_id DESC";
            
    $stmt = $pdo->query($sql);
    $toutesReclamations = $stmt->fetchAll();
    
    // Regroupement par astronaute et par date (tranche de quelques minutes)
    foreach ($toutesReclamations as $rec) {
        $astroId = $rec['astronaute_id'] ?? 0;
        $dateKey = substr($rec['date_reclamation'], 0, 16); 
        $groupKey = $astroId . '_' . $dateKey;
        
        if (!isset($commandesGroupées[$groupKey])) {
            $astroNom = trim(($rec['prenom_astronaute'] ?? '') . ' ' . ($rec['nom_astronaute'] ?? ''));
            if (empty($astroNom)) $astroNom = 'Astronaute #' . $astroId;
            
            $commandesGroupées[$groupKey] = [
                'astronaute' => $astroNom,
                'date' => $rec['date_reclamation'],
                'categories' => [
                    'repas' => null,
                    'snack' => null,
                    'boisson' => null
                ]
            ];
        }
        
        // Utilisation directe du meal_type et du nom pour un classement précis
        $type = strtolower(trim($rec['meal_type'] ?? ''));
        $nomRepas = strtolower(trim($rec['nom_repas'] ?? ''));
        
        if (strpos($type, 'boisson') !== false || strpos($nomRepas, 'eau') !== false || strpos($nomRepas, 'jus') !== false) {
            $commandesGroupées[$groupKey]['categories']['boisson'] = $rec;
        } elseif (strpos($type, 'snack') !== false || strpos($type, 'dessert') !== false || strpos($nomRepas, 'barre') !== false || strpos($nomRepas, 'fraise') !== false || strpos($nomRepas, 'chips') !== false) {
            $commandesGroupées[$groupKey]['categories']['snack'] = $rec;
        } else {
            $commandesGroupées[$groupKey]['categories']['repas'] = $rec;
        }
    }
    
} catch (PDOException $e) {
    $errorMsg = "Erreur SQL : " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Commandes Groupées - Station Spatiale</title>
    <style>
        body { font-family: Arial, sans-serif; background: #1a1a2e; color: white; padding: 30px; margin: 0; }
        h1 { text-align: center; color: #e2e8f0; }
        .error { color: #ffcccc; background: rgba(255,0,0,0.3); padding: 15px; border-radius: 8px; max-width: 900px; margin: 0 auto 20px auto; text-align: center; }
        .success { color: #ccffcc; background: rgba(0,255,0,0.2); padding: 15px; border-radius: 8px; max-width: 900px; margin: 0 auto 20px auto; text-align: center; }
        .commande-card { background: rgba(255,255,255,0.05); border: 1px solid rgba(255,255,255,0.1); border-radius: 10px; padding: 20px; margin-bottom: 20px; max-width: 900px; margin-left: auto; margin-right: auto; }
        .commande-header { display: flex; justify-content: space-between; border-bottom: 1px solid rgba(255,255,255,0.1); padding-bottom: 10px; margin-bottom: 15px; font-size: 1.1rem; font-weight: bold; color: #38bdf8; }
        .items-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 15px; }
        .item-box { background: rgba(0,0,0,0.3); padding: 12px; border-radius: 6px; text-align: center; }
        .item-box img { width: 50px; height: 50px; object-fit: cover; border-radius: 4px; margin-bottom: 5px; background: #444; display: block; margin-left: auto; margin-right: auto; }
        .item-title { font-size: 0.95rem; color: #fff; font-weight: bold; margin-top: 5px; }
        .item-category { font-size: 0.75rem; text-transform: uppercase; color: #38bdf8; font-weight: bold; margin-bottom: 5px; }
        .btn-valider { background: #4ade80; color: #1a1a2e; border: none; padding: 10px 20px; font-size: 1rem; font-weight: bold; border-radius: 6px; cursor: pointer; float: right; }
        .btn-valider:hover { background: #22c55e; }
        .clearfix::after { content: ""; clear: both; display: table; }
        .empty-slot { color: #64748b; padding: 25px 0; font-size: 0.9rem; }
    </style>
</head>
<body>
    <h1>👨‍🚀 Commandes Groupées de l'Équipage</h1>

    <?php if ($errorMsg): ?>
        <div class="error"><?= htmlspecialchars($errorMsg) ?></div>
    <?php endif; ?>

    <?php if ($successMsg): ?>
        <div class="success"><?= htmlspecialchars($successMsg) ?></div>
    <?php endif; ?>

    <?php if (!empty($commandesGroupées)): ?>
        <?php foreach ($commandesGroupées as $groupKey => $commande): ?>
            <div class="commande-card">
                <form method="POST">
                    <div class="commande-header">
                        <span>🚀 <?= htmlspecialchars($commande['astronaute']) ?></span>
                        <span style="font-size: 0.9rem; color: #94a3b8;">📅 <?= htmlspecialchars($commande['date']) ?></span>
                    </div>

                    <div class="items-grid">
                        <!-- 1. Colonne REPAS -->
                        <div class="item-box">
                            <div class="item-category">Repas</div>
                            <?php if ($commande['categories']['repas']): ?>
                                <?php 
                                    $item = $commande['categories']['repas'];
                                    $imgSrc = !empty($item['image_repas']) ? 'data:image/png;base64,' . base64_encode($item['image_repas']) : '';
                                ?>
                                <?php if ($imgSrc): ?><img src="<?= $imgSrc ?>" alt=""><?php endif; ?>
                                <div class="item-title"><?= htmlspecialchars($item['nom_repas'] ?? 'Repas') ?></div>
                                <div style="font-size: 0.8rem; color: #a1a1aa; margin-top: 4px;">Portion : <?= htmlspecialchars($item['portion_size']) ?></div>
                                <input type="hidden" name="valider_ids[]" value="<?= $item['id'] ?>">
                            <?php else: ?>
                                <div class="empty-slot">Aucun repas</div>
                            <?php endif; ?>
                        </div>

                        <!-- 2. Colonne SNACK -->
                        <div class="item-box">
                            <div class="item-category">Snack</div>
                            <?php if ($commande['categories']['snack']): ?>
                                <?php 
                                    $item = $commande['categories']['snack'];
                                    $imgSrc = !empty($item['image_repas']) ? 'data:image/png;base64,' . base64_encode($item['image_repas']) : '';
                                ?>
                                <?php if ($imgSrc): ?><img src="<?= $imgSrc ?>" alt=""><?php endif; ?>
                                <div class="item-title"><?= htmlspecialchars($item['nom_repas'] ?? 'Snack') ?></div>
                                <div style="font-size: 0.8rem; color: #a1a1aa; margin-top: 4px;">Portion : <?= htmlspecialchars($item['portion_size']) ?></div>
                                <input type="hidden" name="valider_ids[]" value="<?= $item['id'] ?>">
                            <?php else: ?>
                                <div class="empty-slot">Aucun snack</div>
                            <?php endif; ?>
                        </div>

                        <!-- 3. Colonne BOISSON -->
                        <div class="item-box">
                            <div class="item-category">Boisson</div>
                            <?php if ($commande['categories']['boisson']): ?>
                                <?php 
                                    $item = $commande['categories']['boisson'];
                                    $imgSrc = !empty($item['image_repas']) ? 'data:image/png;base64,' . base64_encode($item['image_repas']) : '';
                                ?>
                                <?php if ($imgSrc): ?><img src="<?= $imgSrc ?>" alt=""><?php endif; ?>
                                <div class="item-title"><?= htmlspecialchars($item['nom_repas'] ?? 'Boisson') ?></div>
                                <div style="font-size: 0.8rem; color: #a1a1aa; margin-top: 4px;">Portion : <?= htmlspecialchars($item['portion_size']) ?></div>
                                <input type="hidden" name="valider_ids[]" value="<?= $item['id'] ?>">
                            <?php else: ?>
                                <div class="empty-slot">Aucune boisson</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="clearfix">
                        <button type="submit" class="btn-valider">✔️ Valider toute la commande</button>
                    </div>
                </form>
            </div>
        <?php endforeach; ?>
    <?php else: ?>
        <div style="text-align: center; color: #94a3b8; margin-top: 50px;">Aucune commande groupée en attente.</div>
    <?php endif; ?>
</body>
</html>