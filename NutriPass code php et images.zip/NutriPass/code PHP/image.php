<?php
$host    = 'bdd-test.f-dufour.com';
$port    = 2222;
$db      = 'foodtech_test';
$user    = 'foodtech_admin';
$pass    = '5Ve*r93HiyM$5C@ILi9O';
$charset = 'utf8mb4';
$dsn     = "mysql:host=$host;port=$port;dbname=$db;charset=$charset";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    http_response_code(404);
    exit;
}

try {
    $pdo = new PDO($dsn, $user, $pass, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $stmt = $pdo->prepare("SELECT image_repas FROM repas WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row && !empty($row['image_repas'])) {
        // Détection automatique du type MIME (jpeg, png, webp...)
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->buffer($row['image_repas']) ?: 'image/jpeg';
        
        header("Content-Type: $mime");
        echo $row['image_repas'];
        exit;
    }
} catch (Exception $e) {
    // Échec silencieux
}

http_response_code(404);